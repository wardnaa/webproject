<?php
class databases {
    var $host = "127.0.0.1";
    var $username = "root";
    var $password = "";
    var $database = "universitas";
    var $koneksi;

    public function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->password, $this->database) or die("failed");
    }

    // Fungsi unuk membuat Member
    public function register($nama,$username,$password,$jabatan) {
        $insert = mysqli_query($this-koneksi,"INSERT INTO TBL VALUES ('$nama','$username','$password','$jabatan')");
        return $insert;
    }

    

    // Fungsi Login admin 
    public function login($username,$password,$remember) {
        $query = mysqli_query($this->koneksi,"SELECT * FROM tb_users where username='$username'");
        $data_users = mysqli_fetch_assoc($query);
        // Validasi Paassword untuk user yang akan login
        if(password_verify($password,$data_users['password'])) {
            // validasi jabatan user yang login 
                // jika yang login adalah user dengan jabatan admin
                $_SESSION['username'] = $username;
                $_SESSION['nama'] = $data_users['nama'];
                $_SESSION['jabatan'] = $data_users['jabatan'];
                $_SESSION['is_login'] = TRUE;
                return TRUE;

            // Fungsi Remember Passoword 
            if($remember) {
                setcookie('username', $username, time() + (60 * 60 *24 *5), '/');
                setcookie('nama', $data_users['nama'], time() + (60 * 60 * 24 * 5), '/');
            }
        }
    }

    // Fungsi Relogin untuk users
    public function relogin($username) {
        $query = mysqli_query($this->koneksi,"SELECT * FROM tb_users where username='$username'");
        $data_users = $query->fetch_array();
        $_SESSION['username'] = $username;
        $_SESSION['nama'] = $data_users['nama'];
        $_SESSION['is_login'] = TRUE;
    }

    public function online($session,$username) {
        // Cheking user Session
        $cheking = mysqli_query($this->koneksi,"SELECT * FROM tb_session WHERE sesi='$session' AND username='$username'");
        $result = mysqli_num_rows($cheking);

        // kondisi untuk proses cheking user session
        if ($result == "0") {
            // kondisi jika session dari user tidak ada di dalam databases
            $insert = mysqli_query($this->koneksi,"INSERT INTO tb_session VALUE ('$session','$username')");
            return $insert;
        }
        // ini dipindah ke dasboard admin
        // $aktif = mysqli_query($this->koneksi,"SELECT * FROM tb_session");
        // $hasil = mysqli_num_rows($aktif);
        // echo $hasil;

        
    }
    // fucntion count user
    public function loaduser() {
        $user = mysqli_query($this->koneksi,"SELECT * FROM tb_session");
        $jumblah = mysqli_num_rows($user);
        // $number = sprintf('%04d',$jumblah);
        $number = str_pad($jumblah, 4, '0,', STR_PAD_LEFT);
        echo $number;

    }
    // fucntion untuk menghapus session user yang sudah logout dari dari databases
    public function offline($session) {
        $hancur = mysqli_query($this->koneksi,"DELETE FROM tb_session WHERE sesi='$session'");
        return $hancur;
    }

    // public function pengunjung($session) {
    //     $pengu
    // }


    
}
?>